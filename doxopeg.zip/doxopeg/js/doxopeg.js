// JavaScript Document
var x=$(document);
x.ready(inicializar);

function inicializar(){
	$('#inicio').css(
		{'display':'block'}
	)
	$('#logo').css(
		{'margin':'-80px 0px 0px 720px'}
	).animate(
		{'margin':'62px 0px 0px 720px',
		'opacity':'1'
		},700,'swing'
	)
	
	
	$('.marca_logo_index').css(
		{'margin':'30px auto 0px -227px'}
	).animate(
		{'margin':'30px auto 0px 143px',
		'opacity':'1'
		},1500,'swing'
	)
	
	$('#img1_pag2_index').css(
		{'margin':'-155px auto 0px 1060px'}
	).animate(
		{'margin':'-155px auto 0px 728px',
		'opacity':'1'
		},800,'swing'
	)
	
	$(".marca_logo").hide();
	$(".marca_logo").fadeIn(3000);
	
	
	
	
	

	
	$('#text_header').css(
		{'margin':'-330px auto 0px 630px'}
	).animate(
		{'margin':'-140px auto 0px 630px',
		'opacity':'1'
		},900,'swing'
	)
	
	$('#text_tit_pag1').css(
		{'margin':'0px auto 0px 354px'}
	).animate(
		{'margin':'0px auto 0px -50px',
		'opacity':'1'
		},900,'swing'
	)
	
	$('#text_ti2_pag1').css(
		{'margin':'0px auto 0px 302px'}
	).animate(
		{'margin':'0px auto 0px -50px',
		'opacity':'1'
		},900,'swing'
	)
	
	$("#img1_pag1").hide();
	$("#img1_pag1").fadeIn(3000);
	
	$('#tit2_pag1').css(
		{'margin':'5px auto 0px 647px'}
	).animate(
		{'margin':'5px auto 0px -50px',
		'opacity':'1'
		},900,'swing'
	)
	

	$('#parr1_pag1').css(
		{'margin':'5px auto 0px 325px'}
	).animate(
		{'margin':'5px auto 0px -23px',
		'opacity':'1'
		},900,'swing'
	)
	
	$('.footer_right').css(
		{'margin':'-79px auto 0px 890px'}
	).animate(
		{'margin':'0px auto 0px 890px',
		'opacity':'1'
		},600,'swing'
	)
	
	$('#img1_pag2').css(
		{'margin':'-281px auto 0px 460px'}
	).animate(
		{'margin':'-155px auto 0px 460px',
		'opacity':'1'
		},600,'swing'
	)
	
	$('#text_pag2').css(
		{'margin':'0px auto 0px 246px'}
	).animate(
		{'margin':'0px auto 0px -50px',
		'opacity':'1'
		},600,'swing'
	)
	
	
	
	$('#ref_cuad_esta_pag2').css(
		{'margin':'5px auto 0px -360px'}
	).animate(
		{'margin':'5px auto 0px -50px',
		'opacity':'1'
		},900,'swing'
	)
	$("#tit2_cuad_esta_pag3").hide();
	$("#tit2_cuad_esta_pag3").fadeIn(3000);
	
	$("#cuad_estad1_pag3").hide();
	$("#cuad_estad1_pag3").fadeIn(3000);
	
	$('#ref_cuad_esta_pag3').css(
		{'margin':'5px auto 0px -296px'}
	).animate(
		{'margin':'5px auto 0px -78px',
		'opacity':'1'
		},1000,'swing'
	)
	
	$('#text_pag4').css(
		{'margin':'35px auto 0px 168px'}
	).animate(
		{'margin':'35px auto 0px -50px',
		'opacity':'1'
		},1000,'swing'
	)
	
	
	$("#cuad_estad_izq_pag4").hide();
	$("#cuad_estad_izq_pag4").fadeIn(3000);
	
	$("#cuad_estad_der_pag4").hide();
	$("#cuad_estad_der_pag4").fadeIn(3000);
	
	
	$('#text_pie_pag4 ').css(
		{'margin':'35px auto 0px 196px'}
	).animate(
		{'margin':'35px auto 0px -50px',
		'opacity':'1'
		},1000,'swing'
	)

	$(".marca_logo_pag5").hide();
	$(".marca_logo_pag5").fadeIn(3000);
	
	$('#img1_pag5').css(
		{'margin':'-281px auto 0px 460px'}
	).animate(
		{'margin':'-155px auto 0px 460px',
		'opacity':'1'
		},600,'swing'
	)
	
	$('.circ_vin_pag5').css(
		{'margin':'29px auto 0px -238px'}
	).animate(
		{'margin':'29px auto 0px -152px',
		'opacity':'1'
		},600,'swing'
	)
	
	$('.tit1_parr_pag5').css(
		{'margin':'-55px auto 0px 207px'}
	).animate(
		{'margin':'-55px auto 0px -60px',
		'opacity':'1'
		},600,'swing'
	)
	
	$("#text1_parr_pag5").hide();
	$("#text1_parr_pag5").fadeIn(3000);
	
	$("#text3_parr_pag5").hide();
	$("#text3_parr_pag5").fadeIn(4500);
	
	$('#text4_parr_pag5').css(
		{'margin':'60px auto 0px 245px'}
	).animate(
		{'margin':'60px auto 0px -88px',
		'opacity':'1'
		},600,'swing'
	)
	
	
	
	
	
	$('#circ_img_pag6').css(
		{'margin':'-98px auto 0px 442px'}
	).animate(
		{'margin':'30px auto 0px 442px',
		'opacity':'1'
		},1000,'swing'
	)
	
	$('#footer_ultimo').css(
		{'margin':'30px auto 0px -272px'}
	).animate(
		{'margin':'30px auto 0px 2px',
		'opacity':'1'
		},1000,'swing'
	)
	
		
}